import type { ReactNode } from "react";
import { Brand } from "../CaseSelection";
import { studioStore, useStudio, type PatientStatus, type Role } from "../../state/studioStore";

export const btn = "inline-flex h-11 items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50";
export const btnPrimary = `${btn} bg-ink text-white hover:bg-ink-2`;
export const btnOutline = `${btn} border border-line bg-card text-ink hover:border-ink-3 hover:bg-paper`;

const STATUS: Record<PatientStatus, { label: string; cls: string }> = {
  draft: { label: "Draft", cls: "bg-amber-soft text-amber-900 border-amber-700/30" },
  published: { label: "Published", cls: "bg-teal-soft text-teal-deep border-teal/30" },
  archived: { label: "Archived", cls: "bg-paper-2 text-ink-2 border-line" },
};

export function StatusBadge({ status }: { status: PatientStatus }) {
  const s = STATUS[status];
  return <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold ${s.cls}`}>{s.label}</span>;
}

export function DemoRoleSwitch({ role, onChange }: { role: Role; onChange: (r: Role) => void }) {
  return (
    <div className="flex items-center gap-2.5" title="Prototype navigation only. Nothing here is sign-in or access control.">
      <span id="demo-role-label" className="text-xs font-semibold uppercase tracking-[0.12em] text-ink-3">
        Demo role
      </span>
      <div role="group" aria-labelledby="demo-role-label" className="flex rounded-full border border-line bg-card p-0.5">
        {(["faculty", "student"] as const).map((r) => (
          <button
            key={r}
            type="button"
            aria-pressed={role === r}
            onClick={() => role !== r && onChange(r)}
            className={`h-9 rounded-full px-4 text-sm font-semibold capitalize transition ${role === r ? "bg-ink text-white" : "text-ink-2 hover:text-ink"}`}
          >
            {r}
          </button>
        ))}
      </div>
    </div>
  );
}

/** Shared top bar and notice strip so Faculty and Student views look identical. */
export function TopBar({ role, onRole, nav, notice }: { role: Role; onRole: (r: Role) => void; nav?: ReactNode; notice: string }) {
  const { user } = useStudio();
  return (
    <>
      <header className="sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-8 px-6">
          <div className="flex h-16 items-center gap-3">
            <Brand />
            <span className="rounded-full border border-line bg-card px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-teal-deep">
              {role === "faculty" ? "Patient Studio" : "Student"}
            </span>
          </div>
          {user?.role === "faculty" && (
            <div className="ml-auto flex min-h-16 items-center py-2">
              <DemoRoleSwitch role={role} onChange={onRole} />
            </div>
          )}
        </div>
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 px-6">
          <div className="min-w-0 overflow-x-auto">{nav}</div>
          {user && (
            <div className="flex items-center gap-3 py-2 text-sm">
              <span className="max-w-[14rem] truncate text-ink-2" title={user.email}>{user.email}</span>
              <button onClick={() => studioStore.signOut()} className="h-9 rounded-full border border-line bg-card px-4 font-semibold text-ink hover:border-ink-3">Sign out</button>
            </div>
          )}
        </div>
      </header>
      <div className="border-b border-dashed border-amber-700/30 bg-amber-soft/60">
        <p className="mx-auto max-w-6xl px-6 py-2 text-xs text-amber-900">{notice}</p>
      </div>
    </>
  );
}
