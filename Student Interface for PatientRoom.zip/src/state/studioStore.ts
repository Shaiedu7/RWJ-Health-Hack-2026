import { useSyncExternalStore } from "react";
import { publicCases } from "../data/publicCases";
import type { Difficulty, ParsedPatient } from "../domain/patientImport";

/**
 * Local prototype store for the faculty Patient Library (browser localStorage, separate from the
 * student encounter key so saved encounters are never touched). This is storage on this browser,
 * not a backend save. `patientRepository` is the replaceable boundary a real service would implement.
 */

export type Role = "student" | "faculty";
export type PatientStatus = "draft" | "published" | "archived";
export type Origin = "builtin" | "created" | "imported" | "duplicate";

export interface PatientRecord {
  id: string;
  name: string;
  chiefComplaint: string;
  summary: string;
  status: PatientStatus;
  /** Version number of the latest version. Versioned editing arrives with the editor. */
  version: number;
  tags: string[];
  difficulty: Difficulty | null;
  origin: Origin;
  /** Student encounter case this record maps to. Only set for patients that already have a published version. */
  publishedCaseId?: string;
  archivedFrom?: "draft" | "published";
  /** Faculty-entered description the draft was started from. */
  sourceDescription?: string;
  /** How the draft's content came to be. "demo-unconnected" means no generation service ran. */
  generation?: "demo-unconnected";
  /** Imported columns that have no field in this pass. Kept so the editor can use them later. */
  unmapped?: Record<string, string>;
}

export const STUDIO_KEY = "patientroom.studio.v1";
const uid = () => "pt_" + Math.random().toString(36).slice(2, 10);

const seed = (): PatientRecord[] =>
  publicCases.map((c) => ({
    id: c.id,
    name: c.patientName,
    chiefComplaint: c.concern,
    summary: c.intro,
    status: "published",
    version: 1,
    tags: c.encounterType.split("·").map((t) => t.trim()),
    difficulty: null,
    origin: "builtin",
    publishedCaseId: c.id,
  }));

interface Snapshot {
  role: Role;
  /** Demo sign-in label only. No password is ever stored. */
  user: { email: string; role: Role } | null;
  records: PatientRecord[];
  loadError: string | null;
}

function load(): Snapshot {
  try {
    const raw = localStorage.getItem(STUDIO_KEY);
    if (!raw) return { role: "student", user: null, records: seed(), loadError: null };
    const p = JSON.parse(raw) as { role?: Role; user?: { email?: string; role?: Role } | null; records?: PatientRecord[] };
    if (!Array.isArray(p.records)) throw new Error("Saved patient data has an unexpected shape.");
    return { role: p.role === "faculty" ? "faculty" : "student", user: typeof p.user?.email === "string" ? { email: p.user.email, role: p.user.role === "faculty" || p.user.role === "student" ? p.user.role : p.role === "faculty" ? "faculty" : "student" } : null, records: p.records, loadError: null };
  } catch (e) {
    return { role: "student", user: null, records: [], loadError: e instanceof Error ? e.message : "Saved patient data could not be read." };
  }
}

let snap: Snapshot = load();
const listeners = new Set<() => void>();

/** Persist first; only publish the new state if the browser accepted the write. */
function commit(next: Partial<Snapshot>) {
  const candidate = { ...snap, ...next };
  try {
    localStorage.setItem(STUDIO_KEY, JSON.stringify({ role: candidate.role, user: candidate.user, records: candidate.records }));
  } catch {
    throw new Error("This browser could not store the change (storage may be full or blocked). Nothing was saved.");
  }
  snap = candidate;
  listeners.forEach((l) => l());
}

export const studioStore = {
  get: () => snap,
  subscribe(l: () => void) {
    listeners.add(l);
    return () => void listeners.delete(l);
  },
  setRole(role: Role) {
    if (snap.user?.role === "student" && role === "faculty") return;
    try {
      commit({ role });
    } catch {
      snap = { ...snap, role };
      listeners.forEach((l) => l());
    }
  },
  signIn(email: string, role: Role) {
    commit({ user: { email, role }, role });
  },
  signOut() {
    commit({ user: null });
  },
  reload() {
    snap = { ...load(), role: snap.role };
    listeners.forEach((l) => l());
  },
  resetRecords() {
    commit({ records: seed(), loadError: null });
  },
};

export function useStudio() {
  return useSyncExternalStore(studioStore.subscribe, studioStore.get);
}

export const isStartable = (r: PatientRecord) => r.status === "published" && !!r.publishedCaseId && publicCases.some((c) => c.id === r.publishedCaseId);

export interface NewRecordInput {
  name: string;
  chiefComplaint?: string;
  summary?: string;
  tags?: string[];
  difficulty?: Difficulty | null;
  origin: Origin;
  sourceDescription?: string;
  generation?: "demo-unconnected";
  unmapped?: Record<string, string>;
}

const blank = (i: NewRecordInput): PatientRecord => ({
  id: uid(),
  name: i.name,
  chiefComplaint: i.chiefComplaint ?? "",
  summary: i.summary ?? "",
  status: "draft",
  version: 1,
  tags: i.tags ?? [],
  difficulty: i.difficulty ?? null,
  origin: i.origin,
  sourceDescription: i.sourceDescription,
  generation: i.generation,
  unmapped: i.unmapped && Object.keys(i.unmapped).length ? i.unmapped : undefined,
});

/** Replace with API calls (list/create/duplicate/archive) when a backend exists. */
export interface PatientRepository {
  list(): Promise<PatientRecord[]>;
  get(id: string): PatientRecord | undefined;
  create(input: NewRecordInput): Promise<PatientRecord>;
  importMany(rows: ParsedPatient[]): Promise<PatientRecord[]>;
  duplicate(id: string): Promise<PatientRecord>;
  setArchived(id: string, archived: boolean): Promise<PatientRecord>;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const find = (id: string) => {
  const r = snap.records.find((x) => x.id === id);
  if (!r) throw new Error("This patient no longer exists.");
  return r;
};

export const patientRepository: PatientRepository = {
  async list() {
    await sleep(250);
    if (snap.loadError) throw new Error(snap.loadError);
    return snap.records;
  },
  get: (id) => snap.records.find((r) => r.id === id),
  async create(input) {
    await sleep(300);
    const rec = blank(input);
    commit({ records: [rec, ...snap.records] });
    return rec;
  },
  async importMany(rows) {
    await sleep(300);
    const recs = rows.map((p) => blank({ ...p, origin: "imported" }));
    commit({ records: [...recs, ...snap.records] });
    return recs;
  },
  async duplicate(id) {
    await sleep(350);
    const src = find(id);
    const rec: PatientRecord = {
      ...blank({ name: `${src.name} (copy)`, chiefComplaint: src.chiefComplaint, summary: src.summary, tags: src.tags, difficulty: src.difficulty, origin: "duplicate", sourceDescription: src.sourceDescription, generation: src.generation, unmapped: src.unmapped }),
    };
    const i = snap.records.findIndex((r) => r.id === id);
    const records = [...snap.records];
    records.splice(i, 0, rec);
    commit({ records });
    return rec;
  },
  async setArchived(id, archived) {
    await sleep(300);
    const src = find(id);
    const next: PatientRecord = archived
      ? { ...src, status: "archived", archivedFrom: src.status === "published" ? "published" : "draft" }
      : { ...src, status: src.archivedFrom ?? "draft", archivedFrom: undefined };
    commit({ records: snap.records.map((r) => (r.id === id ? next : r)) });
    return next;
  },
};
