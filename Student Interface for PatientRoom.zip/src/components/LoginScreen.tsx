import { useState } from "react";
import { Brand } from "./CaseSelection";
import { studioStore, type Role } from "../state/studioStore";

export default function LoginScreen() {
  const [role, setRole] = useState<Role>("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const addr = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(addr)) return setError("Enter a valid email address.");
    if (!password) return setError("Enter a password.");
    try {
      studioStore.signIn(addr, role);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
    }
  };

  const field = "mt-2 h-12 w-full rounded-2xl border border-line bg-paper px-4 text-[15px] text-ink placeholder:text-ink-3 focus:border-teal focus:bg-card";
  return (
    <div className="grid min-h-dvh place-items-center bg-paper px-6 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 flex justify-center"><Brand /></div>
        <form onSubmit={submit} noValidate className="rounded-3xl border border-line bg-card p-8">
          <h1 className="font-display text-3xl text-ink">Sign in</h1>
          <p className="mt-2 text-ink-2">Choose how you are using PatientRoom.</p>

          <div role="group" aria-label="Sign in as" className="mt-6 grid grid-cols-2 rounded-full border border-line bg-paper p-1">
            {(["student", "faculty"] as const).map((r) => (
              <button key={r} type="button" aria-pressed={role === r} onClick={() => setRole(r)} className={`h-10 rounded-full text-sm font-semibold capitalize transition ${role === r ? "bg-ink text-white" : "text-ink-2 hover:text-ink"}`}>
                {r}
              </button>
            ))}
          </div>

          <label htmlFor="login-email" className="mt-6 block text-sm font-semibold text-ink">Email</label>
          <input id="login-email" type="email" autoComplete="username" value={email} onChange={(e) => { setEmail(e.target.value); setError(null); }} className={field} placeholder="you@school.edu" />
          <label htmlFor="login-pass" className="mt-4 block text-sm font-semibold text-ink">Password</label>
          <input id="login-pass" type="password" autoComplete="current-password" value={password} onChange={(e) => { setPassword(e.target.value); setError(null); }} className={field} />

          <div aria-live="polite">{error && <p role="alert" className="mt-4 rounded-xl border border-danger/40 bg-danger-soft px-4 py-3 text-sm text-danger">{error}</p>}</div>
          <button type="submit" className="mt-6 h-12 w-full rounded-full bg-ink text-sm font-semibold text-white transition hover:bg-ink-2">
            Sign in as {role}
          </button>
          <p className="mt-5 rounded-xl border border-dashed border-amber-700/40 bg-amber-soft px-4 py-3 text-xs leading-relaxed text-amber-900">
            <strong>Demo sign-in, not authentication.</strong> No accounts exist and no server is connected. Any email and password lets you in, the password is not checked or saved, and your role is simply the one you pick.
          </p>
        </form>
      </div>
    </div>
  );
}
