import { useCallback, useEffect, useState } from "react";
import Icon from "../Icon";
import { isStartable, patientRepository, studioStore, useStudio, type PatientRecord, type PatientStatus } from "../../state/studioStore";
import { btnOutline, btnPrimary, StatusBadge } from "./parts";

type Action = { id: string; kind: "duplicate" | "archive" | "restore" };
type Filter = "all" | PatientStatus;

interface Props {
  onOpen: (id: string) => void;
  onNew: () => void;
  onStartEncounter: (caseId: string) => void;
}

function Meta({ r }: { r: PatientRecord }) {
  const shown = r.tags.slice(0, 3);
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {shown.map((t) => (
        <span key={t} className="rounded-full bg-paper-2 px-2.5 py-1 text-xs font-medium text-ink-2">{t}</span>
      ))}
      {r.tags.length > 3 && <span className="text-xs text-ink-3" title={r.tags.slice(3).join(", ")}>+{r.tags.length - 3} more</span>}
      <span className={`rounded-full border px-2.5 py-1 text-xs font-medium ${r.difficulty ? "border-teal/30 text-teal-deep" : "border-line text-ink-3"}`}>
        {r.difficulty ? r.difficulty : "Difficulty not set"}
      </span>
    </div>
  );
}

function Who({ r }: { r: PatientRecord }) {
  return (
    <div>
      <div className="flex items-baseline gap-2">
        <span className="font-display text-xl text-ink">{r.name}</span>
        <span className="font-mono text-xs text-ink-3">v{r.version}</span>
      </div>
      <p className="mt-0.5 text-sm text-ink-3">{r.chiefComplaint || "Chief complaint not entered"}</p>
    </div>
  );
}

export default function PatientLibrary({ onOpen, onNew, onStartEncounter }: Props) {
  const { records } = useStudio();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<Action | null>(null);
  const [notice, setNotice] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [confirmReset, setConfirmReset] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      await patientRepository.list();
    } catch (e) {
      setError(e instanceof Error ? e.message : "The patient library could not be loaded.");
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  const run = async (r: PatientRecord, kind: Action["kind"]) => {
    if (busy) return;
    setBusy({ id: r.id, kind });
    setNotice(null);
    try {
      if (kind === "duplicate") {
        const copy = await patientRepository.duplicate(r.id);
        setNotice({ tone: "ok", text: `Created “${copy.name}” as a separate draft. “${r.name}” is unchanged.` });
      } else if (kind === "archive") {
        await patientRepository.setArchived(r.id, true);
        setNotice({ tone: "ok", text: `Archived “${r.name}”. Students can no longer start new encounters with it; encounters already saved are kept.` });
      } else {
        const back = await patientRepository.setArchived(r.id, false);
        setNotice({ tone: "ok", text: `Restored “${r.name}” as ${back.status}.` });
      }
    } catch (e) {
      setNotice({ tone: "err", text: e instanceof Error ? e.message : "The action failed." });
    } finally {
      setBusy(null);
    }
  };

  const counts = { all: records.length, draft: 0, published: 0, archived: 0 } as Record<Filter, number>;
  records.forEach((r) => counts[r.status]++);
  const rows = filter === "all" ? records : records.filter((r) => r.status === filter);

  const renderActions = (r: PatientRecord) => {
    const mine = busy?.id === r.id ? busy.kind : null;
    const dis = !!busy;
    return (
      <div className="flex flex-wrap gap-2">
        <button className={btnOutline} onClick={() => onOpen(r.id)} disabled={dis} aria-label={`Open ${r.name}`}>Open</button>
        <button className={btnOutline} onClick={() => void run(r, "duplicate")} disabled={dis} aria-label={`Duplicate ${r.name}`}>
          <Icon name="copy" size={15} />{mine === "duplicate" ? "Duplicating…" : "Duplicate"}
        </button>
        {r.status === "archived" ? (
          <button className={btnOutline} onClick={() => void run(r, "restore")} disabled={dis} aria-label={`Restore ${r.name}`}>{mine === "restore" ? "Restoring…" : "Restore"}</button>
        ) : (
          <button className={btnOutline} onClick={() => void run(r, "archive")} disabled={dis} aria-label={`Archive ${r.name}`}>
            <Icon name="archive" size={15} />{mine === "archive" ? "Archiving…" : "Archive"}
          </button>
        )}
        {isStartable(r) && (
          <button className={btnPrimary} onClick={() => onStartEncounter(r.publishedCaseId!)} disabled={dis} aria-label={`Start encounter with ${r.name}`}>Start Encounter</button>
        )}
      </div>
    );
  };

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl text-ink md:text-5xl">Patient Library</h1>
          <p className="mt-2 max-w-xl text-ink-2">Manage the patients students can practise with. Only published patients appear in student case selection.</p>
        </div>
        <button className={btnPrimary} onClick={onNew}><Icon name="plus" size={16} />New patient</button>
      </div>

      <div aria-live="polite" className="mt-6">
        {notice && (
          <p role={notice.tone === "err" ? "alert" : "status"} className={`rounded-2xl border px-5 py-3.5 text-[15px] ${notice.tone === "err" ? "border-danger/40 bg-danger-soft text-danger" : "border-teal/40 bg-teal-soft text-teal-deep"}`}>
            {notice.text}
          </p>
        )}
      </div>

      <section className="mt-6 overflow-hidden rounded-3xl border border-line bg-card" aria-label="Patients" aria-busy={loading}>
        {loading ? (
          <div role="status" aria-label="Loading patients" className="divide-y divide-line">
            {[0, 1, 2].map((i) => (
              <div key={i} className="flex items-center gap-6 px-6 py-6">
                <div className="flex-1 space-y-2.5"><div className="h-5 w-48 animate-pulse rounded bg-paper-2" /><div className="h-4 w-72 max-w-full animate-pulse rounded bg-paper-2" /></div>
                <div className="hidden h-8 w-24 animate-pulse rounded-full bg-paper-2 md:block" />
              </div>
            ))}
            <span className="sr-only">Loading patients…</span>
          </div>
        ) : error ? (
          <div role="alert" className="p-8">
            <p className="font-display text-2xl text-ink">The patient library could not be loaded.</p>
            <p className="mt-2 max-w-xl text-ink-2">{error}</p>
            <div className="mt-5 flex flex-wrap gap-3">
              <button className={btnPrimary} onClick={() => { studioStore.reload(); void load(); }}>Try again</button>
              {!confirmReset ? (
                <button className={btnOutline} onClick={() => setConfirmReset(true)}>Reset patient data…</button>
              ) : (
                <button className={`${btnOutline} border-danger/50 text-danger`} onClick={() => { try { studioStore.resetRecords(); setConfirmReset(false); void load(); } catch (e) { setError(e instanceof Error ? e.message : "Reset failed."); } }}>
                  Confirm: replace patient data with the demo patients
                </button>
              )}
            </div>
            <p className="mt-3 text-sm text-ink-3">Resetting does not touch students' saved encounters.</p>
          </div>
        ) : records.length === 0 ? (
          <div className="px-6 py-16 text-center">
            <p className="font-display text-3xl text-ink">No patients yet.</p>
            <p className="mx-auto mt-2 max-w-sm text-ink-2">Describe a case to create a patient profile for review.</p>
            <button className={`${btnPrimary} mt-6`} onClick={onNew}>Create a patient</button>
          </div>
        ) : (
          <>
            <div role="group" aria-label="Filter by status" className="flex flex-wrap gap-2 border-b border-line px-6 py-4">
              {(["all", "draft", "published", "archived"] as const).map((f) => (
                <button key={f} aria-pressed={filter === f} onClick={() => setFilter(f)} className={`h-9 rounded-full border px-4 text-sm font-semibold capitalize transition ${filter === f ? "border-ink bg-ink text-white" : "border-line text-ink-2 hover:border-ink-3"}`}>
                  {f} <span className="font-mono text-xs opacity-70">{counts[f]}</span>
                </button>
              ))}
            </div>
            {rows.length === 0 ? (
              <p className="px-6 py-12 text-center text-ink-2">No {filter} patients.</p>
            ) : (
              <>
                <table className="hidden w-full text-left md:table">
                  <thead>
                    <tr className="border-b border-line text-xs font-semibold uppercase tracking-[0.12em] text-ink-3">
                      <th scope="col" className="px-6 py-3">Patient</th>
                      <th scope="col" className="px-3 py-3">Status</th>
                      <th scope="col" className="px-3 py-3">Tags and difficulty</th>
                      <th scope="col" className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {rows.map((r) => (
                      <tr key={r.id} className="align-top">
                        <td className="px-6 py-5"><Who r={r} /></td>
                        <td className="px-3 py-5"><StatusBadge status={r.status} /></td>
                        <td className="max-w-[16rem] px-3 py-5"><Meta r={r} /></td>
                        <td className="px-6 py-5">{renderActions(r)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <ul className="divide-y divide-line md:hidden">
                  {rows.map((r) => (
                    <li key={r.id} className="space-y-4 px-5 py-5">
                      <div className="flex items-start justify-between gap-3"><Who r={r} /><StatusBadge status={r.status} /></div>
                      <Meta r={r} />
                      {renderActions(r)}
                    </li>
                  ))}
                </ul>
              </>
            )}
          </>
        )}
      </section>
      <p className="mt-4 text-sm text-ink-3">Stored on this browser, not a backend save.</p>
    </div>
  );
}
