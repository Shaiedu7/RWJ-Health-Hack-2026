import CaseSelection, { Brand } from "./components/CaseSelection";
import EncounterFeedback from "./components/EncounterFeedback";
import EncounterRoom from "./components/EncounterRoom";
import EncounterSetup from "./components/EncounterSetup";
import { getPublicCase, publicCases } from "./data/publicCases";
import FacultyApp from "./components/faculty/FacultyApp";
import { TopBar } from "./components/faculty/parts";
import LoginScreen from "./components/LoginScreen";
import { isStartable, studioStore, useStudio } from "./state/studioStore";
import { useEncounterStore } from "./state/useEncounterStore";

function Transition({ title, sub }: { title: string; sub: string }) {
  return (
    <div className="grid min-h-dvh place-items-center bg-paper px-6" role="status" aria-live="polite">
      <div className="flex flex-col items-center text-center">
        <Brand />
        <span className="anim-ring mt-12 inline-block size-14 rounded-full border-[3px] border-teal-soft border-t-teal" />
        <h1 className="mt-8 font-display text-3xl text-ink">{title}</h1>
        <p className="mt-2 text-ink-3">{sub}</p>
      </div>
    </div>
  );
}

export default function App() {
  const s = useEncounterStore();
  const { role: viewRole, user, records, loadError } = useStudio();
  const role = user?.role === "student" ? "student" : viewRole;
  const { state } = s;
  const enc = state.encounter;

  if (!user) return <LoginScreen />;

  if (role === "faculty" && !s.phase) {
    return (
      <FacultyApp
        onRole={studioStore.setRole}
        onStartEncounter={(caseId) => {
          studioStore.setRole("student");
          s.openSetup(caseId);
        }}
      />
    );
  }

  if (s.phase === "preparing") return <Transition title="Preparing patient…" sub="Setting up the examination room" />;
  if (s.phase === "assessing") return <Transition title="Generating your feedback…" sub="Reviewing the transcript against the case objectives" />;

  if (state.view === "setup") {
    const patient = getPublicCase(state.setupCaseId ?? publicCases[0].id);
    return <EncounterSetup patient={patient} prefs={state.prefs} onBegin={(p) => void s.begin(patient.id, p)} onBack={s.backToCases} />;
  }

  if (state.view === "room" && enc && enc.status === "active") {
    return (
      <EncounterRoom
        encounter={enc}
        patient={getPublicCase(enc.caseId)}
        prefs={state.prefs}
        pending={s.pending}
        lastReply={s.lastReply}
        saveStatus={s.saveStatus}
        onAsk={(t) => void s.ask(t)}
        onRequestRecord={s.requestRecord}
        onMarkSeen={s.markSeen}
        onNotes={s.setNotes}
        onFinish={s.finish}
        onBack={s.backToCases}
      />
    );
  }

  if (state.view === "feedback" && enc?.feedback) {
    return <EncounterFeedback encounter={enc} patient={getPublicCase(enc.caseId)} onTryAgain={s.tryAgain} onBack={s.backToCases} />;
  }

  const offered = loadError ? publicCases : publicCases.filter((c) => records.some((r) => r.publishedCaseId === c.id && isStartable(r)));
  return (
    <CaseSelection
      cases={offered}
      allCases={publicCases}
      active={enc}
      onStart={s.openSetup}
      onResume={s.resume}
      header={<TopBar role="student" onRole={studioStore.setRole} nav={<nav aria-label="Student" className="flex gap-6"><span aria-current="page" className="relative flex h-12 items-center px-1 text-[15px] font-semibold text-ink after:absolute after:inset-x-0 after:bottom-0 after:h-0.5 after:bg-teal">Practice encounters</span></nav>} notice="Demo mode · synthetic patients. Signed in with a demo login: this is not real authentication or access control." />}
    />
  );
}
