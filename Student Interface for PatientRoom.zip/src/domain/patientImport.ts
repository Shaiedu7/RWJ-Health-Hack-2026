export const MAX_IMPORT = 25;
export const MAX_FILE_BYTES = 2 * 1024 * 1024;
export const DIFFICULTIES = ["Beginner", "Intermediate", "Advanced"] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];

export interface ParsedPatient {
  name: string;
  chiefComplaint: string;
  summary: string;
  tags: string[];
  difficulty: Difficulty | null;
  unmapped: Record<string, string>;
}
export interface ImportFailure {
  record: number;
  reason: string;
}
export type ImportParse =
  | { ok: false; error: string }
  | {
      ok: true;
      format: "JSON" | "CSV";
      total: number;
      patients: ParsedPatient[];
      failures: ImportFailure[];
      mapping: { field: string; source: string }[];
      unmappedColumns: string[];
    };

const FIELDS = {
  name: { label: "Patient name", aliases: ["name", "patient", "patientname", "fullname"] },
  chiefComplaint: { label: "Chief complaint", aliases: ["chiefcomplaint", "complaint", "concern", "presentingcomplaint", "cc"] },
  summary: { label: "Case summary", aliases: ["summary", "casesummary", "description", "casedescription"] },
  tags: { label: "Tags", aliases: ["tags", "tag", "keywords"] },
  difficulty: { label: "Difficulty", aliases: ["difficulty", "level"] },
} as const;
type FieldKey = keyof typeof FIELDS;

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

function fieldFor(key: string): FieldKey | null {
  const n = norm(key);
  for (const f of Object.keys(FIELDS) as FieldKey[]) if ((FIELDS[f].aliases as readonly string[]).includes(n)) return f;
  return null;
}

/** RFC 4180-style CSV: quoted fields, escaped quotes, CRLF. Returns null on an unterminated quote. */
export function parseCsv(text: string): string[][] | null {
  const src = text.replace(/^﻿/, "");
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  let touched = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"' && cell === "") {
      quoted = true;
      touched = true;
    } else if (ch === ",") {
      row.push(cell);
      cell = "";
      touched = true;
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && src[i + 1] === "\n") i++;
      if (touched || cell !== "") {
        row.push(cell);
        rows.push(row);
      }
      row = [];
      cell = "";
      touched = false;
    } else {
      cell += ch;
      touched = true;
    }
  }
  if (quoted) return null;
  if (touched || cell !== "") {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

const str = (v: unknown) => (v == null ? "" : typeof v === "string" ? v.trim() : typeof v === "object" ? JSON.stringify(v) : String(v).trim());

function build(raw: Record<string, unknown>, map: Map<string, FieldKey>): { patient?: ParsedPatient; reason?: string } {
  const get: Partial<Record<FieldKey, unknown>> = {};
  const unmapped: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw)) {
    const f = map.get(k);
    if (f && get[f] === undefined) get[f] = v;
    else if (str(v)) unmapped[k] = str(v);
  }
  const name = str(get.name);
  if (!name) return { reason: "Patient name is missing." };
  if (name.length > 120) return { reason: "Patient name is longer than 120 characters." };
  let difficulty: Difficulty | null = null;
  const d = str(get.difficulty);
  if (d) {
    difficulty = DIFFICULTIES.find((x) => x.toLowerCase() === d.toLowerCase()) ?? null;
    if (!difficulty) return { reason: `Difficulty “${d}” is not one of ${DIFFICULTIES.join(", ")}.` };
  }
  const tagsRaw = get.tags;
  const tags = (Array.isArray(tagsRaw) ? tagsRaw.map(str) : str(tagsRaw).split(/[;,|]/)).map((t) => t.trim()).filter(Boolean);
  if (tags.some((t) => t.length > 40)) return { reason: "A tag is longer than 40 characters." };
  return { patient: { name, chiefComplaint: str(get.chiefComplaint), summary: str(get.summary), tags: [...new Set(tags)], difficulty, unmapped } };
}

export function parseImport(fileName: string, text: string): ImportParse {
  const ext = fileName.toLowerCase().split(".").pop();
  let records: Record<string, unknown>[] = [];
  const failures: ImportFailure[] = [];
  let format: "JSON" | "CSV";
  let keys: string[] = [];

  if (ext === "json") {
    format = "JSON";
    let data: unknown;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return { ok: false, error: `This file is not valid JSON (${e instanceof Error ? e.message : "parse error"}). Nothing was imported.` };
    }
    const list = Array.isArray(data) ? data : data && typeof data === "object" && Array.isArray((data as { patients?: unknown }).patients) ? (data as { patients: unknown[] }).patients : null;
    if (!list) return { ok: false, error: "Expected a JSON array of patient records, or an object with a “patients” array. Nothing was imported." };
    if (!list.length) return { ok: false, error: "The file contains no patient records." };
    if (list.length > MAX_IMPORT) return { ok: false, error: `The file contains ${list.length} records. The limit is ${MAX_IMPORT}. Nothing was imported.` };
    list.forEach((r, i) => {
      if (r && typeof r === "object" && !Array.isArray(r)) records.push(r as Record<string, unknown>);
      else {
        records.push({});
        failures.push({ record: i + 1, reason: "This entry is not an object with named fields." });
      }
    });
    keys = [...new Set(records.flatMap((r) => Object.keys(r)))];
  } else if (ext === "csv") {
    format = "CSV";
    const rows = parseCsv(text);
    if (!rows) return { ok: false, error: "This CSV is malformed: a quoted field is never closed. Nothing was imported." };
    if (!rows.length) return { ok: false, error: "The file is empty." };
    const header = rows[0].map((h) => h.trim());
    const data = rows.slice(1);
    if (!data.length) return { ok: false, error: "The CSV has a header row but no patient records." };
    if (data.length > MAX_IMPORT) return { ok: false, error: `The file contains ${data.length} records. The limit is ${MAX_IMPORT}. Nothing was imported.` };
    keys = header;
    data.forEach((cells, i) => {
      if (cells.length !== header.length) {
        records.push({});
        failures.push({ record: i + 1, reason: `Row has ${cells.length} fields but the header has ${header.length}. Check for an unquoted comma.` });
      } else records.push(Object.fromEntries(header.map((h, j) => [h, cells[j]])));
    });
  } else return { ok: false, error: "Unsupported file type. Choose a .json or .csv file." };

  const map = new Map<string, FieldKey>();
  const taken = new Set<FieldKey>();
  const mapping: { field: string; source: string }[] = [];
  for (const k of keys) {
    const f = fieldFor(k);
    if (f && !taken.has(f)) {
      taken.add(f);
      map.set(k, f);
      mapping.push({ field: FIELDS[f].label, source: k });
    }
  }
  if (!taken.has("name")) {
    return { ok: false, error: `No ${format === "CSV" ? "column" : "field"} could be mapped to Patient name. Expected one of: ${FIELDS.name.aliases.join(", ")}. Nothing was imported.` };
  }
  const unmappedColumns = keys.filter((k) => !map.has(k));

  const patients: ParsedPatient[] = [];
  records.forEach((r, i) => {
    if (failures.some((f) => f.record === i + 1)) return;
    const res = build(r, map);
    if (res.patient) patients.push(res.patient);
    else failures.push({ record: i + 1, reason: res.reason ?? "Invalid record." });
  });
  failures.sort((a, b) => a.record - b.record);
  return { ok: true, format, total: records.length, patients, failures, mapping, unmappedColumns };
}

export const exampleCsv = 'name,chief complaint,summary,tags,difficulty\n"Alvarez, Rosa",Cough for two weeks,"Retired nurse, ex-smoker","respiratory;chronic",Intermediate\n';
