import { patientRepository } from "../../state/studioStore";
import { useStudio } from "../../state/studioStore";
import { btnOutline, StatusBadge } from "./parts";

const TABS = ["Profile", "Artifacts", "Knowledge", "Check & Publish"];

export default function EditorPlaceholder({ id, fresh, onBack }: { id: string; fresh?: string; onBack: () => void }) {
  useStudio();
  const rec = patientRepository.get(id);
  if (!rec) {
    return (
      <div className="rounded-3xl border border-line bg-card p-8">
        <p className="font-display text-2xl">This patient was not found.</p>
        <button onClick={onBack} className={`${btnOutline} mt-5`}>Back to Patient Library</button>
      </div>
    );
  }
  return (
    <div>
      <button onClick={onBack} className="text-sm font-semibold text-teal-deep hover:underline">← Patient Library</button>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <h1 className="font-display text-4xl text-ink">{rec.name}</h1>
        <StatusBadge status={rec.status} />
        <span className="font-mono text-sm text-ink-3">v{rec.version}</span>
      </div>
      {fresh && (
        <p role="status" className="mt-5 rounded-2xl border border-teal/40 bg-teal-soft px-5 py-4 text-[15px] text-teal-deep">{fresh}</p>
      )}
      <div className="mt-6 rounded-3xl border border-line bg-card p-6 md:p-8">
        <p className="inline-block rounded-full border border-dashed border-amber-700/40 bg-amber-soft px-3 py-1 text-xs font-semibold text-amber-900">Placeholder · editor not built yet</p>
        <h2 className="mt-4 font-display text-2xl text-ink">The patient editor arrives in the next pass</h2>
        <p className="mt-2 max-w-2xl text-ink-2">This record is saved as a draft on this browser. Planned tabs, not yet available:</p>
        <ul className="mt-4 flex flex-wrap gap-2" aria-label="Planned editor tabs">
          {TABS.map((t) => (
            <li key={t} className="rounded-full border border-line bg-paper px-4 py-2 text-sm font-semibold text-ink-3">{t}</li>
          ))}
        </ul>
        <dl className="mt-8 grid gap-5 text-[15px] md:grid-cols-2">
          <div>
            <dt className="text-xs font-semibold uppercase tracking-[0.12em] text-ink-3">Chief complaint</dt>
            <dd className="mt-1 text-ink">{rec.chiefComplaint || <span className="text-ink-3">Not entered</span>}</dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-[0.12em] text-ink-3">Difficulty</dt>
            <dd className="mt-1 text-ink">{rec.difficulty ?? <span className="text-ink-3">Not set</span>}</dd>
          </div>
          <div className="md:col-span-2">
            <dt className="text-xs font-semibold uppercase tracking-[0.12em] text-ink-3">{rec.sourceDescription ? "Case description you entered" : "Case summary"}</dt>
            <dd className="mt-1 whitespace-pre-wrap text-ink">{rec.summary || <span className="text-ink-3">Not entered</span>}</dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
