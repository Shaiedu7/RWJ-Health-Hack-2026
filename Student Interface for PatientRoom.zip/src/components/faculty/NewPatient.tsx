import { useRef, useState } from "react";
import Icon from "../Icon";
import { MAX_FILE_BYTES, MAX_IMPORT, parseImport, type ImportParse } from "../../domain/patientImport";
import { MAX_DESCRIPTION, MIN_DESCRIPTION, profileGenerator } from "../../services/profileGenerator";
import { patientRepository } from "../../state/studioStore";
import { btnOutline, btnPrimary } from "./parts";

type Done = { imported: number; failures: { record: number; reason: string }[]; mapping: { field: string; source: string }[]; unmapped: string[]; format: string; total: number };

export default function NewPatient({ onCreated, onLibrary }: { onCreated: (id: string, notice: string) => void; onLibrary: () => void }) {
  const [desc, setDesc] = useState("");
  const [genBusy, setGenBusy] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);

  const [file, setFile] = useState<File | null>(null);
  const [impBusy, setImpBusy] = useState(false);
  const [impError, setImpError] = useState<string | null>(null);
  const [done, setDone] = useState<Done | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const locked = useRef(false);

  const generate = async () => {
    if (locked.current) return;
    if (desc.trim().length < MIN_DESCRIPTION) {
      setGenError(desc.trim() ? `Describe the case in at least ${MIN_DESCRIPTION} characters.` : "Enter a case description first.");
      return;
    }
    locked.current = true;
    setGenBusy(true);
    setGenError(null);
    try {
      const g = await profileGenerator.generate(desc);
      const rec = await patientRepository.create({
        name: g.name,
        chiefComplaint: g.chiefComplaint,
        summary: g.summary,
        origin: "created",
        sourceDescription: desc.trim(),
        generation: g.mode,
      });
      onCreated(rec.id, "Demo draft created. No generation service is connected, so no profile fields were generated: your description was saved as the case summary and everything else is blank for you to complete.");
    } catch (e) {
      setGenError(e instanceof Error ? e.message : "The draft could not be created.");
    } finally {
      locked.current = false;
      setGenBusy(false);
    }
  };

  const pick = (f: File | null) => {
    setFile(f);
    setImpError(null);
    setDone(null);
  };

  const runImport = async () => {
    if (locked.current) return;
    setDone(null);
    if (!file) return setImpError("Choose a JSON or CSV file first.");
    if (!/\.(json|csv)$/i.test(file.name)) return setImpError("Unsupported file type. Choose a .json or .csv file.");
    if (file.size > MAX_FILE_BYTES) return setImpError("This file is larger than 2 MB. Split it into smaller files.");
    locked.current = true;
    setImpBusy(true);
    setImpError(null);
    try {
      let text: string;
      try {
        text = await file.text();
      } catch {
        throw new Error("The file could not be read. Choose it again.");
      }
      const parsed: ImportParse = parseImport(file.name, text);
      if (!parsed.ok) throw new Error(parsed.error);
      const created = parsed.patients.length ? await patientRepository.importMany(parsed.patients) : [];
      setDone({ imported: created.length, failures: parsed.failures, mapping: parsed.mapping, unmapped: parsed.unmappedColumns, format: parsed.format, total: parsed.total });
      setFile(null);
      if (fileRef.current) fileRef.current.value = "";
    } catch (e) {
      setImpError(e instanceof Error ? e.message : "The import failed.");
    } finally {
      locked.current = false;
      setImpBusy(false);
    }
  };

  return (
    <div>
      <div className="mx-auto max-w-3xl rounded-3xl border border-line bg-card p-6 md:p-10">
        <section aria-labelledby="describe-h">
          <h1 id="describe-h" className="font-display text-4xl text-ink">New patient</h1>
          <p className="mt-3 text-ink-2">Describe a case to create a patient profile. Anything generated needs your review before students can use it.</p>
          <label htmlFor="case-desc" className="mt-6 block text-sm font-semibold text-ink">Describe a case</label>
          <textarea
            id="case-desc"
            value={desc}
            onChange={(e) => { setDesc(e.target.value); if (genError) setGenError(null); }}
            disabled={genBusy}
            maxLength={MAX_DESCRIPTION}
            rows={9}
            placeholder="e.g. A 58-year-old retired teacher with a day of stomach discomfort. She minimises symptoms and came in at her daughter's urging…"
            aria-invalid={!!genError}
            aria-describedby="gen-help gen-err"
            className="mt-2 min-h-56 w-full resize-y rounded-2xl border border-line bg-paper px-4 py-3.5 text-[15px] leading-relaxed text-ink placeholder:text-ink-3 focus:border-teal focus:bg-card disabled:opacity-60"
          />
          <p id="gen-help" className="mt-2 rounded-xl border border-dashed border-amber-700/40 bg-amber-soft px-4 py-3 text-sm text-amber-900">
            <strong>Demo only · {profileGenerator.label}.</strong> Creating a draft here saves your description as the case summary and leaves the other fields blank. Nothing is generated from it.
          </p>
          <div id="gen-err" aria-live="polite">
            {genError && <p role="alert" className="mt-3 rounded-xl border border-danger/40 bg-danger-soft px-4 py-3 text-sm text-danger">{genError} Your text has been kept.</p>}
          </div>
          <div className="mt-5 flex items-center gap-4">
            <button className={btnPrimary} onClick={() => void generate()} disabled={genBusy}>
              {genBusy ? (<><span className="anim-ring inline-block size-4 rounded-full border-2 border-white/40 border-t-white" />Creating draft…</>) : "Generate Patient Profile"}
            </button>
            <span className="text-xs text-ink-3">{desc.length}/{MAX_DESCRIPTION}</span>
          </div>
        </section>

        <hr className="my-10 border-line" />

        <section aria-labelledby="import-h">
          <h2 id="import-h" className="font-display text-3xl text-ink">Import a dataset</h2>
          <p className="mt-2 text-ink-2">Up to {MAX_IMPORT} patient records. Imported patients remain drafts until reviewed and published.</p>
          <label htmlFor="import-file" className="mt-6 block text-sm font-semibold text-ink">JSON or CSV file</label>
          <input
            id="import-file"
            ref={fileRef}
            type="file"
            accept=".json,.csv,application/json,text/csv"
            disabled={impBusy}
            onChange={(e) => pick(e.target.files?.[0] ?? null)}
            className="mt-2 block w-full cursor-pointer rounded-2xl border border-dashed border-line bg-paper px-4 py-3 text-sm text-ink-2 file:mr-4 file:h-9 file:cursor-pointer file:rounded-full file:border-0 file:bg-paper-2 file:px-4 file:text-sm file:font-semibold file:text-ink"
          />
          <p className="mt-2 text-sm text-ink-3">Recognised fields: patient name (required), chief complaint, summary, tags, difficulty. Other columns are kept but not used yet.</p>
          <div aria-live="polite">
            {impError && <p role="alert" className="mt-4 rounded-xl border border-danger/40 bg-danger-soft px-4 py-3 text-sm text-danger">{impError}</p>}
          </div>
          <button className={`${btnPrimary} mt-5`} onClick={() => void runImport()} disabled={impBusy}>
            {impBusy ? (<><span className="anim-ring inline-block size-4 rounded-full border-2 border-white/40 border-t-white" />Importing…</>) : (<><Icon name="upload" size={16} />Import Patients</>)}
          </button>

          {done && (
            <div role="status" className={`mt-6 rounded-2xl border p-5 ${done.imported ? "border-teal/40 bg-teal-soft" : "border-danger/40 bg-danger-soft"}`}>
              <p className="font-semibold text-ink">
                {done.imported ? `Imported ${done.imported} of ${done.total} record${done.total === 1 ? "" : "s"} as drafts.` : `Nothing imported: all ${done.total} record${done.total === 1 ? "" : "s"} failed validation.`}
              </p>
              {done.failures.length > 0 && (
                <div className="mt-3">
                  <p className="text-sm font-semibold text-danger">{done.failures.length} not imported:</p>
                  <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-ink-2">
                    {done.failures.map((f) => (<li key={f.record}>Record {f.record}: {f.reason}</li>))}
                  </ul>
                </div>
              )}
              <details className="mt-3 text-sm text-ink-2">
                <summary className="cursor-pointer font-semibold text-ink">Field mapping ({done.format})</summary>
                <ul className="mt-2 list-disc space-y-1 pl-5">
                  {done.mapping.map((m) => (<li key={m.field}>{m.field} ← “{m.source}”</li>))}
                  {done.unmapped.length > 0 && <li>Not mapped (kept on the draft, not shown yet): {done.unmapped.map((u) => `“${u}”`).join(", ")}</li>}
                </ul>
              </details>
              {done.imported > 0 && <button className={`${btnOutline} mt-4`} onClick={onLibrary}>View in Patient Library</button>}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
