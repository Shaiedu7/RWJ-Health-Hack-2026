/**
 * Boundary for patient-profile generation. In production this calls a backend endpoint that runs a
 * language model and returns a structured profile for faculty review. No such service is connected
 * to this prototype, so the local implementation does NOT generate anything: it returns a blank draft
 * that carries the faculty member's own description as the case summary.
 */
export interface GeneratedDraft {
  name: string;
  chiefComplaint: string;
  summary: string;
  /** "demo-unconnected": no model ran; fields other than the description are empty. */
  mode: "demo-unconnected";
}
export interface ProfileGenerator {
  connected: boolean;
  label: string;
  generate(description: string): Promise<GeneratedDraft>;
}

export const MIN_DESCRIPTION = 20;
export const MAX_DESCRIPTION = 4000;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const profileGenerator: ProfileGenerator = {
  connected: false,
  label: "No generation service is connected",
  async generate(description) {
    await sleep(900);
    const text = description.trim();
    if (text.length < MIN_DESCRIPTION) throw new Error(`Describe the case in at least ${MIN_DESCRIPTION} characters.`);
    if (text.length > MAX_DESCRIPTION) throw new Error(`The description is longer than ${MAX_DESCRIPTION} characters.`);
    return { name: "Untitled patient (demo draft)", chiefComplaint: "", summary: text, mode: "demo-unconnected" };
  },
};
