import { useState } from "react";
import EditorPlaceholder from "./EditorPlaceholder";
import { TopBar } from "./parts";
import NewPatient from "./NewPatient";
import PatientLibrary from "./PatientLibrary";
import type { Role } from "../../state/studioStore";

type Route = { name: "library" } | { name: "new" } | { name: "editor"; id: string; fresh?: string };

interface Props {
  onRole: (r: Role) => void;
  onStartEncounter: (caseId: string) => void;
}

export default function FacultyApp({ onRole, onStartEncounter }: Props) {
  const [route, setRoute] = useState<Route>({ name: "library" });
  const link = (active: boolean) =>
    `relative flex h-12 shrink-0 items-center px-1 text-[15px] font-semibold transition ${active ? "text-ink after:absolute after:inset-x-0 after:bottom-0 after:h-0.5 after:bg-teal" : "text-ink-3 hover:text-ink"}`;

  return (
    <div className="min-h-dvh bg-paper">
      <TopBar
        role="faculty"
        onRole={onRole}
        notice="Demo role switch is prototype navigation, not sign-in or access control. Patient data is stored on this browser, not a backend save."
        nav={
          <nav aria-label="Patient Studio" className="flex gap-6">
            <button className={link(route.name === "library" || route.name === "editor")} aria-current={route.name === "library" ? "page" : undefined} onClick={() => setRoute({ name: "library" })}>
              Patient Library
            </button>
            <button className={link(route.name === "new")} aria-current={route.name === "new" ? "page" : undefined} onClick={() => setRoute({ name: "new" })}>
              New Patient
            </button>
          </nav>
        }
      />
      <main className="mx-auto max-w-6xl px-6 pb-24 pt-10">
        {route.name === "library" && (
          <PatientLibrary onOpen={(id) => setRoute({ name: "editor", id })} onNew={() => setRoute({ name: "new" })} onStartEncounter={onStartEncounter} />
        )}
        {route.name === "new" && <NewPatient onCreated={(id, fresh) => setRoute({ name: "editor", id, fresh })} onLibrary={() => setRoute({ name: "library" })} />}
        {route.name === "editor" && <EditorPlaceholder id={route.id} fresh={route.fresh} onBack={() => setRoute({ name: "library" })} />}
      </main>
    </div>
  );
}

